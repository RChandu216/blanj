// Assume we have a logged-in user with their email stored in a variable called "loggedInUserEmail"
const loggedInUserEmail = "user@example.com";

// Assume we have an array of protected music files with their details
const protectedMusicFiles = [{
        id: 1,
        title: "Protected Song 1",
        allowedEmails: ["user1@example.com", "user2@example.com"]
    },
    {
        id: 2,
        title: "Protected Song 2",
        allowedEmails: ["user2@example.com", "user3@example.com"]
    },
    {
        id: 3,
        title: "Protected Song 3",
        allowedEmails: ["user4@example.com"]
    }
];

// Function to check if the logged-in user has access to a protected music file
function hasAccessToMusicFile(file) {
    if (file.allowedEmails.includes(loggedInUserEmail)) {
        return true;
    }
    return false;
}

// Get all the music files accessible to the logged-in user
const accessibleMusicFiles = protectedMusicFiles.filter(file => hasAccessToMusicFile(file));

// Display the accessible music files
console.log(accessibleMusicFiles);